#include <stdio.h>
#include <assert.h>

#ifndef PROJECT_TESTS_QUEUE_LINKED_LIST_H
#define PROJECT_TESTS_QUEUE_LINKED_LIST_H

void run_all_tests();

void test_empty();
void test_all();

#endif //PROJECT_TESTS_QUEUE_LINKED_LIST_H
