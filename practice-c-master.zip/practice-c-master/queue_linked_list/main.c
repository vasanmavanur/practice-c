#include <stdlib.h>
#include "queue.h"
#include "queue.c"
#include "tests_queue_linked_list.h"
#include "tests_queue_linked_list.c"

int main(int argc, char *argv[]) {

  run_all_tests();

  return EXIT_SUCCESS;
}