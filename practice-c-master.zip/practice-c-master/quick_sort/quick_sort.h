#include <time.h>
#include <stdlib.h>  // for srand

#ifndef PROJECT_QUICK_SORT_H
#define PROJECT_QUICK_SORT_H

// Sorts the given array
void quick_sort(int numbers[], int left, int right);

#endif  // PROJECT_QUICK_SORT_H
