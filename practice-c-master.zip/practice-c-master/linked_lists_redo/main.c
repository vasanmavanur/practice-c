#include "linked_list.h"
#include "linked_list.c"
#include "tests.h"
#include "tests.c"

// Implements a singly linked list

int main(int argc, char *argv[]) {
  run_all_tests();

  return EXIT_SUCCESS;
}
