#include "hash_table.h"
#include "hash_table.c"
#include "tests.h"
#include "tests.c"

int main(int argc, char *argv[]) {
  run_all_tests();

  return EXIT_SUCCESS;
}
