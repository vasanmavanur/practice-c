#include <assert.h>

#ifndef PROJECT_TESTS_HASH_H
#define PROJECT_TESTS_HASH_H

void run_all_tests();

void test_exists();
void test_add_get();
void test_add_remove();

#endif //PROJECT_TESTS_HASH_H
