#include "queue.h"
#include "queue.c"
#include "tests_queue_array.h"
#include "tests_queue_array.c"

// Implements a queue using an array

int main(int argc, char* argv[]) {
  run_all_tests();

  return EXIT_SUCCESS;
}
